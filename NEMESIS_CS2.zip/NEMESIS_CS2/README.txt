Nemesis Anti-Aim - Private Build v3.1
-------------------------------------

Welcome to Nemesis, the next-gen legit anti-aim solution for CS2.

INSTRUCTIONS:

1. Run "NemesisInstal.exe" ONCE.
   - This installs the core injection module.
  
2. Use "Nemesis.exe" to control anti-aim modes.
   - Interface will show current status (ON/OFF)
   - Toggle using the button. Recommended: keep active during matches.

3. Do NOT rename any files.
   - Renaming may cause injection errors.

4. Supported OS:
   - Windows 10 / 11 (x64)

DISCLAIMER:
This build is for educational purposes only. The author is not responsible for bans or misuse.

Good luck, and stay undetected.